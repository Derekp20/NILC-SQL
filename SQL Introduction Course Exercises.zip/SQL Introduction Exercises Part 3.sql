/*********************
SQL Introduction Course - Part 3

For each Exercise write the code under the Comment.
To run you code, make sure you highlight it before 
clicking execute so that only the selected code is executed.
***********************/

--Exercise 14
-- Challenge exercise. Can you come up with a good subquery question for your 
-- fellow course delegates?





-- Exercise 15
-- From sales.salesorderdetail, select the salesorderid, the orderqty and the 
-- linetotal. From production.product select the product name.





-- Exercise 16
-- Query 1 Write a query that selects the title, firstname, and lastname 
-- fields from person.person. Join to person.emailaddress to also show the 
-- email address for each person.





-- Query 2 Write a query using the sales.salesorderdetail table and the 
-- production.product table.
-- List these details
--	Salesorderid
--	Orderqty
--	Product Name
--	Linetotal
-- The product name is stored in produc􀆟on as Name. Sales.salesorderdetail and 
-- product.product join together using the Produc􀆟d column in both tables.





-- Exercise 17
-- Convert two of your prior queries to run using an alias. Copy them below.





-- Exercise 18
-- Select a persons:
--	Firstname
--	Lastname
--	Addressline1
--	AddressLine2
--	City
--	Postal Code
-- For all rows in address line 2 that contain data (no nulls)
-- Person Names are in Person.Person
-- The address details are in Person.address
-- You’ll need to also join to Person.BusinessEntityAddress to connect names 
-- to addresses






-- Exercise 19
-- Query 1 The table person.person has a persontype column containing a code 
-- identifying the persons relationship to Adventure Works. Write a query 
-- showing the persons firstname, lastname and definition of the persontype 
-- column.
-- The PersonType codes look like this:
--	IN	Individual (retail customer)
--	EM	Employee – Non-Sales
--	SP	Salesperson
--	SC	Store Contact
--	VC	Vendor Contact
--	GC	General Contact





-- Query 2 Create another query that examines the vacation hours taken by 
-- employees. Create a query that lists the employees firstname ,lastname, job 
-- title, and which grades the number of vacation hours based on
--	0 – 30: Low Vacation Hours
--	30 – 70: Expected Vacation Hours
--	>70: High Vacation Hours





-- Exercise 20
-- Using production.product table list all products with a listprice greater 
-- than 500. Show the following columns
--	Product Number
--	Name
--	Color
--	List Price
-- List Price should be correctly formated to GBP. (Pounds Sterling).




-- Exercise 21
-- Using the skills, you have learned and at least one function from the above 
-- create an SQL Question for your colleagues. You MUST be able to provide an 
-- answer if requested.
