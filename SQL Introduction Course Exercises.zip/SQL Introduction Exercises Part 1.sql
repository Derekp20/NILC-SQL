/*********************
SQL Introduction Course

For each Exercise write the code under the Comment.
To run you code, make sure you highlight it before 
clicking execute so that only the selected code is executed.
***********************/

--Exercise 1
--From the table person.person, select and display all the records from the columns.
-- Title
-- Firstname
-- Lastname
-- Middlename




--*******************************************
--Exercise 2
--Select all columns from the table person.address 
--and find all addresses where the city is London.





--*******************************************
--Exercise 3
--Query 1 Using the sales.salesorderheader table 
-- write a query to find all records with a status 
-- of 5 and an onlineorderflag value of 1





--Query 2 Using the sales.salesorderheader table 
-- write a query to find all records for Customer 
-- 11005 (use CustomerID) with an OnlineOrderFlag 
-- of 1





--***********************************************
--Exercise 4
--Query 1 Using the person.person table find all 
-- Last Names star􀆟ng with the leter P




--Query 2 Using the person.address table list the 
-- Address1, City and PostalCode columns for city 
-- names containing the leters X,Y,Z and any other 
-- characters.





--***********************************************
--Exercise 5
--Query 1 List all columns from the table 
-- Sales.SalesOrderHeader where the sales order id 
-- is in the range 45000 – 50000.




--Query 2 List all columns from the table 
-- Sales.SalesOrderHeader where the order date is 
-- in December 2011.




--*********************************************
--Exercise 6
--Query 1 Using the table person.address select 
-- the columns AddressLine1, AddressLine2, City 
-- and Postalcode where the address is from one of 
-- these ci􀆟es:
-- • Cheltenham
-- • Frankfurt
-- • Rhodes
-- • Santa Ana





--Query 2 Using the table Sales.SalesOrderDetail 
-- list these columns
-- • SalesOrderID
-- • OrderQty
-- • ProductID
-- • LineTotal
-- Where the CustomerID is 11015 or 11027. The 
-- customer ID is in table Sales.SalesOrderHeader. 
-- This table also contains the SalesOrderID.




--**********************************************
--Exercise 7
--Update the query below (Example 14) to show only the rows where unit price discount is greater than 0.

SELECT salesorderid
	, unitprice
	,unitpricediscount
	, unitprice * unitpricediscount as [Discounted Price]
FROM sales.SalesOrderDetail;



--In the table Sales.SalesOrderHeader the subtotal 
-- shows the cost of the order before Tax and 
-- Freight costs. Calculate the Subtotal + Freight 
-- for every order. Your query should show the
-- • SalesOrderID
-- • OrderDate
-- • Subtotal
-- • Freight
-- • Subtotal plus freight




--**********************************************
