/********************************
SQL Introduction Exercises Part 2
*********************************/
-- Exercise 8
-- Using the table Produc􀆟on.ProductInventory, work out the total amount of 
-- stock by summing the quan􀆟ty column.




-- Exercise 9
-- How many times is each city name used in the table person.address.






-- Exercise 10
-- Query 1 Using the Produc􀆟on.ProductInventory table list show the following:
--	Shelf Column
--	Bin Column
--	The total of quantity
-- Only where the total quantity is more than 1000.





-- Query 2 Using the Produc􀆟on.ProductInventory table show how many bins are 
-- associated with each shelf. But only do so for Shelves A-F





-- Exercise 11
-- Query 1 Using the Sales.SalesOrderHeader table. Show the columns
--	SalesOrderID
--	OrderDate
--	TotalDue
-- In the order of OrderDate descending





-- Query 2 Using the table produc􀆟on.product
-- Show the columns
--	Name
--	ProductNumber
--	SafetyStockLevel
In the order Name ascending alphabe􀆟cal order where the Color column is Blue






-- Exercise 12
-- Query 1 Using the table, Person.Address create a single column for the 
-- following columns, item must have a comma separating it from the next item.
--	AddresssID
--	AddressLine1
--	City
--	PostalCode
-- Restrict your list to only those addresses in StateProvinceID 14.





-- Query 2 From the table Person.Person generate a full name column that looks 
-- like
--	The ini􀆟al leter of the first name in upper case
--	A space
--	The Last name in upper case
-- Also list of the business entity id for each person.
-- Show these details for people that have a person type of EM





-- Exercise 13
-- Query 1 The table HumanResources.Department contains information about the 
-- company’s employees. This includes the employee Birthdate. Write a query 
-- that shows these details for all employees.
--	National ID Number
--	Job title
--	Birthdate
--	Age. The Employee Age should be calculated based on Todays date.
Order the result by Age to see who the youngest and oldest staff members are.





-- Query 2 Continue using HumanResources.Department to report on hiring 
-- information. Write a query to find the following:
--	National ID Number
--	Jobtitle
--	Month of hire based on Hiredate
-- Make sure the query only looks at employees hired in 2010.




